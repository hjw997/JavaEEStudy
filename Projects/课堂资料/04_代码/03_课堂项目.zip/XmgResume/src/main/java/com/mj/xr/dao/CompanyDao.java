package com.mj.xr.dao;

import com.mj.xr.bean.Company;

public interface CompanyDao extends BaseDao<Company> {

}
