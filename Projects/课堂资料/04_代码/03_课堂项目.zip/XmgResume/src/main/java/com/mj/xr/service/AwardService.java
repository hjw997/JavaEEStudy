package com.mj.xr.service;

import com.mj.xr.bean.Award;

public interface AwardService extends BaseService<Award> {
}
