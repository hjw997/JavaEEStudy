package com.mj.xr.dao;

import com.mj.xr.bean.Website;

public interface WebsiteDao extends BaseDao<Website> {

}

