package com.mj.xr.service.impl;

import com.mj.xr.bean.Project;
import com.mj.xr.service.ProjectService;


public class ProjectServiceImpl extends BaseServiceImpl<Project> implements ProjectService {

}
