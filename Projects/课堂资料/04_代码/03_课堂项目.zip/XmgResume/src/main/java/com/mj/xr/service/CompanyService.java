package com.mj.xr.service;

import com.mj.xr.bean.Company;

public interface CompanyService extends BaseService<Company> {
}
