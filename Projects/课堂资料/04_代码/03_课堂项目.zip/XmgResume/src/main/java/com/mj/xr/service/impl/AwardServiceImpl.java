package com.mj.xr.service.impl;

import com.mj.xr.bean.Award;
import com.mj.xr.service.AwardService;


public class AwardServiceImpl extends BaseServiceImpl<Award> implements AwardService {

//    @Override
//    public boolean remove(List<Integer> ids) {
//        // 删除图片文件
//        return super.remove(ids);
//    }
//
//    @Override
//    public boolean remove(Integer id) {
//        // 删除图片文件
//        return super.remove(id);
//    }
}
