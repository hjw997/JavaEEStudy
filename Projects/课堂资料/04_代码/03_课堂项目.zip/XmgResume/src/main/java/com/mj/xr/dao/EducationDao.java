package com.mj.xr.dao;

import com.mj.xr.bean.Education;

public interface EducationDao extends BaseDao<Education> {

}
