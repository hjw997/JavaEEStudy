package com.mj.xr.service.impl;

import com.mj.xr.bean.Education;
import com.mj.xr.dao.BaseDao;
import com.mj.xr.dao.impl.EducationDaoImpl;
import com.mj.xr.service.EducationService;

public class EducationServiceImpl extends BaseServiceImpl<Education> implements EducationService {

}
