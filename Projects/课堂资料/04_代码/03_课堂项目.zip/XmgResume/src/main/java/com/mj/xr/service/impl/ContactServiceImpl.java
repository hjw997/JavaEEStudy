package com.mj.xr.service.impl;

import com.mj.xr.bean.Contact;
import com.mj.xr.service.ContactService;


public class ContactServiceImpl extends BaseServiceImpl<Contact> implements ContactService {

}
