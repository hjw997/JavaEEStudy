package com.mj.xr.dao;

import com.mj.xr.bean.Project;

public interface ProjectDao extends BaseDao<Project> {

}
