package com.mj.xr.bean;

import com.mj.xr.bean.base.BaseBean;

public class Contact extends BaseBean {
}
