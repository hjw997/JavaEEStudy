package com.mj.xr.dao;

import com.mj.xr.bean.Skill;

public interface SkillDao extends BaseDao<Skill> {
}
