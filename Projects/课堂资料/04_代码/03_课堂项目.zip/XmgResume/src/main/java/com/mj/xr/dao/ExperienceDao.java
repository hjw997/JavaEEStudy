package com.mj.xr.dao;

import com.mj.xr.bean.Experience;

public interface ExperienceDao extends BaseDao<Experience> {

}
