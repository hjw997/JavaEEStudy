package com.mj.xr.service;

import com.mj.xr.bean.Website;

public interface WebsiteService extends BaseService<Website> {

}
