package com.mj.xr.service.impl;

import com.mj.xr.bean.Experience;
import com.mj.xr.service.ExperienceService;


public class ExperienceServiceImpl extends BaseServiceImpl<Experience> implements ExperienceService {

}
