package com.mj.xr.service.impl;

import com.mj.xr.bean.Website;
import com.mj.xr.dao.BaseDao;
import com.mj.xr.dao.impl.WebsiteDaoImpl;
import com.mj.xr.service.WebsiteService;

public class WebsiteServiceImpl extends BaseServiceImpl<Website> implements WebsiteService {

}
