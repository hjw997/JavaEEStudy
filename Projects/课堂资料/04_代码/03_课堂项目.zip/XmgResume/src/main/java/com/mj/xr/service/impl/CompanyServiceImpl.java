package com.mj.xr.service.impl;

import com.mj.xr.bean.Company;
import com.mj.xr.service.CompanyService;


public class CompanyServiceImpl extends BaseServiceImpl<Company> implements CompanyService {

}
