package com.mj.xr.service;

import com.mj.xr.bean.Skill;

public interface SkillService extends BaseService<Skill> {

}
