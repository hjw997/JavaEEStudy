package com.mj.xr.dao;

import com.mj.xr.bean.Award;

public interface AwardDao extends BaseDao<Award> {

}
