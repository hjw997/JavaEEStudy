package com.mj.xr.service.impl;

import com.mj.xr.bean.Skill;
import com.mj.xr.dao.BaseDao;
import com.mj.xr.dao.impl.SkillDaoImpl;
import com.mj.xr.service.SkillService;

public class SkillServiceImpl extends BaseServiceImpl<Skill> implements SkillService {

}
