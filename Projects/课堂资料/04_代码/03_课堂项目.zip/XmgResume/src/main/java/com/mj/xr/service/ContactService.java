package com.mj.xr.service;

import com.mj.xr.bean.Contact;

public interface ContactService extends BaseService<Contact> {
}
