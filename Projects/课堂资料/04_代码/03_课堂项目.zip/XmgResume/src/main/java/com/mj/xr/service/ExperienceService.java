package com.mj.xr.service;

import com.mj.xr.bean.Experience;

public interface ExperienceService extends BaseService<Experience> {
}
