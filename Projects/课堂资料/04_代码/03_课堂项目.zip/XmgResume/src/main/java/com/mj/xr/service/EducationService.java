package com.mj.xr.service;

import com.mj.xr.bean.Education;

public interface EducationService extends BaseService<Education> {

}
