package com.mj.xr.dao;

import com.mj.xr.bean.Contact;

public interface ContactDao extends BaseDao<Contact> {

}
