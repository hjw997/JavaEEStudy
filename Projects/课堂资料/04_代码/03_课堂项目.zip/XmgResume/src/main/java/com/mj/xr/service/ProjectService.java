package com.mj.xr.service;

import com.mj.xr.bean.Project;

public interface ProjectService extends BaseService<Project> {
}
