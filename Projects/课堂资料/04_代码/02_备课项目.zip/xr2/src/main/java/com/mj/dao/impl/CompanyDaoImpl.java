package com.mj.dao.impl;

import com.mj.bean.Company;
import com.mj.bean.result.CompanyPageResult;
import com.mj.beans.util.Sqls;
import com.mj.dao.CompanyDao;

import java.util.ArrayList;
import java.util.List;

public class CompanyDaoImpl extends BaseDaoImpl<Company, CompanyPageResult>
        implements CompanyDao {

}
