package com.mj.service;

import com.mj.bean.Skill;
import com.mj.bean.result.SkillPageResult;

public interface SkillService extends BaseService<Skill, SkillPageResult> {
}
