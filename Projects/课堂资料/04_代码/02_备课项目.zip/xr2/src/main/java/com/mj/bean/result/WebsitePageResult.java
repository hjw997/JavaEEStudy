package com.mj.bean.result;

import com.mj.bean.Website;

public class WebsitePageResult extends PageResult<Website> {
}
