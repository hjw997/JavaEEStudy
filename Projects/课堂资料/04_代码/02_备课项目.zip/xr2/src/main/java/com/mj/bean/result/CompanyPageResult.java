package com.mj.bean.result;

import com.mj.bean.Company;

public class CompanyPageResult extends PageResult<Company> {
}
