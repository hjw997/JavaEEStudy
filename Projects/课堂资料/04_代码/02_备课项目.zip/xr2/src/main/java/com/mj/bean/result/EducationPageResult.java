package com.mj.bean.result;

import com.mj.bean.Education;

public class EducationPageResult extends PageResult<Education> {
}
