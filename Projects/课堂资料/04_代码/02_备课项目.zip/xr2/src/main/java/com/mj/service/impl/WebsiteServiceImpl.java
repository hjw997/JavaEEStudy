package com.mj.service.impl;

import com.mj.bean.Website;
import com.mj.bean.result.WebsitePageResult;
import com.mj.service.WebsiteService;

public class WebsiteServiceImpl
        extends BaseServiceImpl<Website, WebsitePageResult>
        implements WebsiteService {
}
