package com.mj.dao.impl;

import com.mj.bean.Skill;
import com.mj.bean.result.SkillPageResult;
import com.mj.dao.SkillDao;

import java.util.ArrayList;
import java.util.List;

public class SkillDaoImpl extends BaseDaoImpl<Skill, SkillPageResult>
        implements SkillDao {

}
