package com.mj.service.impl;

import com.mj.bean.Education;
import com.mj.bean.result.EducationPageResult;
import com.mj.service.EducationService;

public class EducationServiceImpl
        extends BaseServiceImpl<Education, EducationPageResult>
        implements EducationService {
}
