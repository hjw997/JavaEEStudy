package com.mj.dao;

import com.mj.bean.Skill;
import com.mj.bean.result.SkillPageResult;

public interface SkillDao extends BaseDao<Skill, SkillPageResult> {
}
