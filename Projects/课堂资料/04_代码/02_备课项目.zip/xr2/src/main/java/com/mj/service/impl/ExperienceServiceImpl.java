package com.mj.service.impl;

import com.mj.bean.Experience;
import com.mj.bean.result.ExperiencePageResult;
import com.mj.service.ExperienceService;

public class ExperienceServiceImpl
        extends BaseServiceImpl<Experience, ExperiencePageResult>
        implements ExperienceService {
}
