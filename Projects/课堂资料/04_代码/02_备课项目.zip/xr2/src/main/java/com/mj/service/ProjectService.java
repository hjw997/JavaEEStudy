package com.mj.service;

import com.mj.bean.Project;
import com.mj.bean.result.ProjectPageResult;

public interface ProjectService extends BaseService<Project, ProjectPageResult> {
}
