package com.mj.dao;

import com.mj.bean.Education;
import com.mj.bean.result.EducationPageResult;

public interface EducationDao extends BaseDao<Education, EducationPageResult> {
}
