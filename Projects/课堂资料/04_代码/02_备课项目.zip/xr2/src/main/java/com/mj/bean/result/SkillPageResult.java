package com.mj.bean.result;

import com.mj.bean.Skill;

public class SkillPageResult extends PageResult<Skill> {
}
