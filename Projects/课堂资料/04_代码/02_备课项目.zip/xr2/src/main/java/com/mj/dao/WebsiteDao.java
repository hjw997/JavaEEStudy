package com.mj.dao;

import com.mj.bean.Website;
import com.mj.bean.result.WebsitePageResult;

public interface WebsiteDao extends BaseDao<Website, WebsitePageResult> {
}
