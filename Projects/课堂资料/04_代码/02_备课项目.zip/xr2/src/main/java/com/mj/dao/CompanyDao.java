package com.mj.dao;

import com.mj.bean.Company;
import com.mj.bean.result.CompanyPageResult;

public interface CompanyDao extends BaseDao<Company, CompanyPageResult> {
}
