package com.mj.service.impl;

import com.mj.bean.Skill;
import com.mj.bean.result.SkillPageResult;
import com.mj.service.SkillService;

public class SkillServiceImpl
        extends BaseServiceImpl<Skill, SkillPageResult>
        implements SkillService {
}
