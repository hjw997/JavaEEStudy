package com.mj.dao;

import com.mj.bean.Project;
import com.mj.bean.result.ProjectPageResult;

public interface ProjectDao extends BaseDao<Project, ProjectPageResult> {
}
