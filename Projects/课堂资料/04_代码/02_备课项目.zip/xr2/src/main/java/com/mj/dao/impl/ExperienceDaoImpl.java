package com.mj.dao.impl;

import com.mj.bean.Company;
import com.mj.bean.Experience;
import com.mj.bean.result.ExperiencePageResult;
import com.mj.dao.ExperienceDao;

import java.util.ArrayList;
import java.util.List;

public class ExperienceDaoImpl extends BaseDaoImpl<Experience, ExperiencePageResult>
        implements ExperienceDao {

}
