package com.mj.service.impl;

import com.mj.bean.Company;
import com.mj.bean.result.CompanyPageResult;
import com.mj.service.CompanyService;

public class CompanyServiceImpl
        extends BaseServiceImpl<Company, CompanyPageResult>
        implements CompanyService {
}
