package com.mj.bean.result;

import com.mj.bean.Experience;

public class ExperiencePageResult extends PageResult<Experience> {
}
