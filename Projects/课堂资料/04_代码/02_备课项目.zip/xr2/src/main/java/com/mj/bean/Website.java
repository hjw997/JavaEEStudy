package com.mj.bean;

import com.mj.bean.base.Bean;

public class Website extends Bean {
    private String footer;

    public String getFooter() {
        return footer;
    }

    public void setFooter(String footer) {
        this.footer = footer;
    }
}
