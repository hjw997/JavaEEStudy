package com.mj.service;

import com.mj.bean.Website;
import com.mj.bean.result.WebsitePageResult;

public interface WebsiteService extends BaseService<Website, WebsitePageResult> {
}
