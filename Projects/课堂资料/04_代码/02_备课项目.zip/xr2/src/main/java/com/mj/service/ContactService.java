package com.mj.service;

import com.mj.bean.Contact;
import com.mj.bean.result.ContactPageResult;

public interface ContactService extends BaseService<Contact, ContactPageResult> {
}
