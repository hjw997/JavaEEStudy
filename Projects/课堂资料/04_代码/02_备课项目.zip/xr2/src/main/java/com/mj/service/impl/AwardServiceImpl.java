package com.mj.service.impl;

import com.mj.bean.Award;
import com.mj.bean.result.AwardPageResult;
import com.mj.service.AwardService;

public class AwardServiceImpl
        extends BaseServiceImpl<Award, AwardPageResult>
        implements AwardService {
}
