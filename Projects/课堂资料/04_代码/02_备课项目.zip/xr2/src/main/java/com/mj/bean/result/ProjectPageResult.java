package com.mj.bean.result;

import com.mj.bean.Project;

public class ProjectPageResult extends PageResult<Project> {
}
