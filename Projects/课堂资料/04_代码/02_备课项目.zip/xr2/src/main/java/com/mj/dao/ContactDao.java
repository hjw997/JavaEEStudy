package com.mj.dao;

import com.mj.bean.Contact;
import com.mj.bean.result.ContactPageResult;

public interface ContactDao extends BaseDao<Contact, ContactPageResult> {
}
