package com.mj.service;

import com.mj.bean.Company;
import com.mj.bean.result.CompanyPageResult;

public interface CompanyService extends BaseService<Company, CompanyPageResult> {
}
