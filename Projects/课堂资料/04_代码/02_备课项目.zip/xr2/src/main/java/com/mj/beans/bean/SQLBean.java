package com.mj.beans.bean;

public interface SQLBean {
    Integer getId();
    void setId(Integer id);
}
