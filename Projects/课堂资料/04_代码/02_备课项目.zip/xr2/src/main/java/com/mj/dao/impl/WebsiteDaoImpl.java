package com.mj.dao.impl;

import com.mj.bean.Website;
import com.mj.bean.result.WebsitePageResult;
import com.mj.dao.WebsiteDao;

import java.util.ArrayList;
import java.util.List;

public class WebsiteDaoImpl extends BaseDaoImpl<Website, WebsitePageResult>
        implements WebsiteDao {

}
