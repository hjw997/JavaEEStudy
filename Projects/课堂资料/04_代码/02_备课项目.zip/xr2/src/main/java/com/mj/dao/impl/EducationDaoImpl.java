package com.mj.dao.impl;

import com.mj.bean.Education;
import com.mj.bean.result.EducationPageResult;
import com.mj.dao.EducationDao;

import java.util.ArrayList;
import java.util.List;

public class EducationDaoImpl extends BaseDaoImpl<Education, EducationPageResult>
        implements EducationDao {

}
