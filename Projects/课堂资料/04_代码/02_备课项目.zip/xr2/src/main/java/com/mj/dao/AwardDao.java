package com.mj.dao;

import com.mj.bean.Award;
import com.mj.bean.result.AwardPageResult;

public interface AwardDao extends BaseDao<Award, AwardPageResult> {
}
