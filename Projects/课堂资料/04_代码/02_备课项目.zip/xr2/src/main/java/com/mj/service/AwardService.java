package com.mj.service;

import com.mj.bean.Award;
import com.mj.bean.result.AwardPageResult;

public interface AwardService extends BaseService<Award, AwardPageResult> {
}
