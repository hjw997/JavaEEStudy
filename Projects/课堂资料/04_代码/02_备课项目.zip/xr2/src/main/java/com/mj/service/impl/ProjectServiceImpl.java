package com.mj.service.impl;

import com.mj.bean.Project;
import com.mj.bean.result.ProjectPageResult;
import com.mj.service.ProjectService;

public class ProjectServiceImpl
        extends BaseServiceImpl<Project, ProjectPageResult>
        implements ProjectService {
}
