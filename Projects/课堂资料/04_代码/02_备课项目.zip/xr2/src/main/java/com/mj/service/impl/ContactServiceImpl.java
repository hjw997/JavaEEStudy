package com.mj.service.impl;

import com.mj.bean.Contact;
import com.mj.bean.result.ContactPageResult;
import com.mj.service.ContactService;

public class ContactServiceImpl
        extends BaseServiceImpl<Contact, ContactPageResult>
        implements ContactService {
}
