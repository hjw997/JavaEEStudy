package com.mj.bean.result;

import com.mj.bean.User;

public class UserPageResult extends KeywordPageResult<User> {

}
