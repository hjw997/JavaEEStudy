package com.mj.service;

import com.mj.bean.Education;
import com.mj.bean.result.EducationPageResult;

public interface EducationService extends BaseService<Education, EducationPageResult> {
}
