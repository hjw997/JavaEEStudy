package com.mj.service;

import com.mj.bean.Experience;
import com.mj.bean.result.ExperiencePageResult;

public interface ExperienceService extends BaseService<Experience, ExperiencePageResult> {
}
