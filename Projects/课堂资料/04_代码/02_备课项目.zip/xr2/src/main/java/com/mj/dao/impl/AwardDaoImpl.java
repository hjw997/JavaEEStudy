package com.mj.dao.impl;

import com.mj.bean.Award;
import com.mj.bean.result.AwardPageResult;
import com.mj.dao.AwardDao;

import java.util.ArrayList;
import java.util.List;

public class AwardDaoImpl extends BaseDaoImpl<Award, AwardPageResult>
        implements AwardDao {

}
