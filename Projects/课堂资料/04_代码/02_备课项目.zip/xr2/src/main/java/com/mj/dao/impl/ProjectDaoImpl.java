package com.mj.dao.impl;

import com.mj.bean.Company;
import com.mj.bean.Project;
import com.mj.bean.result.ProjectPageResult;
import com.mj.dao.ProjectDao;

import java.util.ArrayList;
import java.util.List;

public class ProjectDaoImpl extends BaseDaoImpl<Project, ProjectPageResult>
        implements ProjectDao {

}
