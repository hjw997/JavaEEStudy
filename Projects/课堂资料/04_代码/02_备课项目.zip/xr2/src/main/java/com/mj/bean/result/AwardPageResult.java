package com.mj.bean.result;

import com.mj.bean.Award;

public class AwardPageResult extends PageResult<Award> {
}
