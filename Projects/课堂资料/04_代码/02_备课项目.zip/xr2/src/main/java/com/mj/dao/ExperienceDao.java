package com.mj.dao;

import com.mj.bean.Experience;
import com.mj.bean.result.ExperiencePageResult;

public interface ExperienceDao extends BaseDao<Experience, ExperiencePageResult> {
}
