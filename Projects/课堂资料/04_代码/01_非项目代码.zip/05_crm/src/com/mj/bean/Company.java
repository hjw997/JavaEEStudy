package com.mj.bean;

public class Company {
}
