package com.mj;

import com.mj.servlet.CustomerServlet;

import java.lang.reflect.Method;

public class Test {
    public void test1() {

    }

    protected void test2() {

    }

    private void test3() {

    }
}
