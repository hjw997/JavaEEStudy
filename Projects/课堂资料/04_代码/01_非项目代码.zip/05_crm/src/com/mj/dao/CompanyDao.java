package com.mj.dao;

public class CompanyDao {

}
