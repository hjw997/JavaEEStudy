package com.mj;

public class Main2 {
    public static void main(String[] args) {

    }
}
