package com.mj;

import com.alibaba.druid.pool.DruidDataSourceFactory;
import org.dom4j.io.DOMReader;

public class Main {
    public static void main(String[] args) {
        System.out.println(1);
        System.out.println(DruidDataSourceFactory.class);
        System.out.println(DOMReader.class);
        System.out.println(2);
    }
}
